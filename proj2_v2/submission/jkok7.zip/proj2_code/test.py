import unit_tests.sift_unit_test as test
import unit_tests.feature_match_test as test2

#test2.test_feature_matching()
test.test_feature_matching_speed()
#test.test_SIFTNet()
#test.test_get_sift_subgrid_coords()
#test.test_SubGridAccumulationLayer()
